#Group Members
1) Kaan Sancak 21502708
2) Sabit Gökberk Karaca 21401862